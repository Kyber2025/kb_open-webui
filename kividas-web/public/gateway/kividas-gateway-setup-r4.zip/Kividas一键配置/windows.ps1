﻿param([switch]$LibraryOnly)
$ErrorActionPreference = 'Stop'
$script:GatewayUrl = 'https://ai.kividas.com/api'
$script:IdPattern = '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'

function ConvertTo-KiviMap($Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [System.Collections.IDictionary]) {
        $map = [ordered]@{}; foreach ($key in $Value.Keys) { $map[$key] = ConvertTo-KiviMap $Value[$key] }; return ,$map
    }
    if ($Value -is [pscustomobject]) {
        $map = [ordered]@{}; foreach ($p in $Value.PSObject.Properties) { $map[$p.Name] = ConvertTo-KiviMap $p.Value }; return ,$map
    }
    if ($Value -is [array]) { $items = @(); foreach ($item in $Value) { $items += ,(ConvertTo-KiviMap $item) }; return ,$items }
    return $Value
}
function Read-KiviJson($Raw, $Label) {
    if ($null -eq $Raw) { return ,([ordered]@{}) }
    try {
        $value = ConvertTo-KiviMap (ConvertFrom-Json -InputObject $Raw.TrimStart([char]0xfeff))
        if ($value -isnot [System.Collections.IDictionary]) { throw 'not object' }; return ,$value
    } catch { throw "$Label 不是有效 JSON，请先修复；原文件未覆盖。" }
}
function ConvertTo-KiviJson($Value) { return (($Value | ConvertTo-Json -Depth 100) + "`n") }
function Test-KiviCredentials($Key, $InstallationId) {
    $Key = ([string]$Key).Trim(); $InstallationId = ([string]$InstallationId).Trim()
    if ($Key -cnotmatch '^sk-kiv-desktop-[A-Za-z0-9_-]{40,128}$') { throw '请填写完整的 Kividas Gateway API key。' }
    if ($InstallationId -notmatch $script:IdPattern) { throw '安装识别码应为管理员配发的 UUID；不要自行生成或更换。' }
    return @{ key=$Key; id=$InstallationId }
}
function Read-KiviCredentialsText($Text) {
    $keys=@(); $ids=@()
    foreach ($line in $Text.TrimStart([char]0xfeff) -split '\r?\n') {
        if ($line -match '^\s*Gateway API key\s*[:：]\s*(\S+)\s*$') { $keys += $Matches[1] }
        if ($line -match '^\s*(?:安装识别码|Installation ID|值[（(]Value[）)])\s*[:：]\s*(\S+)\s*$') { $ids += $Matches[1] }
    }
    if ($keys.Count -ne 1 -or $ids.Count -ne 1) { throw 'TXT 必须包含一套明确的 Gateway API key 和安装识别码（或“值（Value）”）。请使用后台下载的客户接入资料。' }
    return Test-KiviCredentials $keys[0] $ids[0]
}
function Assert-KiviPath($Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item=Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw '配置路径含符号链接或重解析点，请联系服务方确认位置。' }
        }
        $parent=[IO.Path]::GetDirectoryName($current); if ($parent -eq $current) { break }; $current=$parent
    }
}
function Read-KiviFile($Path) {
    Assert-KiviPath $Path
    if (!(Test-Path -LiteralPath $Path)) { return $null }
    $utf8=New-Object Text.UTF8Encoding($false,$true)
    try { return [IO.File]::ReadAllText($Path,$utf8) } catch { throw '无法读取配置文件，请检查权限和 UTF-8 编码。' }
}
function Protect-KiviFile($Path) {
    if ($env:OS -ne 'Windows_NT') { return } # Isolated portability tests on macOS.
    $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $acl=New-Object Security.AccessControl.FileSecurity
    # Modify ONLY the DACL. Set-Acl's provider can persist Audit/Owner/Group as well,
    # causing SeSecurityPrivilege failures in ordinary, non-elevated sessions.
    # Access-only .NET persistence leaves the SACL and ownership untouched.
    $acl.SetSecurityDescriptorSddlForm(('D:P(A;;FA;;;'+$sid+')(A;;FA;;;SY)'),[Security.AccessControl.AccessControlSections]::Access)
    if ($PSVersionTable.PSEdition -eq 'Core') {
        [IO.FileSystemAclExtensions]::SetAccessControl((New-Object IO.FileInfo($Path)),$acl)
    } else {
        [IO.File]::SetAccessControl($Path,$acl) # Windows PowerShell 5.1 / .NET Framework
    }
}
function Write-KiviFile($Path,$Text) {
    Assert-KiviPath $Path
    $parent=[IO.Path]::GetDirectoryName($Path)
    [void][IO.Directory]::CreateDirectory($parent)
    $temporary=Join-Path $parent ('.kividas-'+[guid]::NewGuid().ToString()+'.tmp')
    try {
        [IO.File]::WriteAllText($temporary,'',(New-Object Text.UTF8Encoding($false)))
        Protect-KiviFile $temporary
        [IO.File]::WriteAllText($temporary,$Text,(New-Object Text.UTF8Encoding($false)))
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temporary,$Path,[NullString]::Value) } else { [IO.File]::Move($temporary,$Path) }
        Protect-KiviFile $Path
    } finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
}
function Remove-KiviFile($Path) { Assert-KiviPath $Path; if ([IO.File]::Exists($Path)) { [IO.File]::Delete($Path) } }
function New-KiviPlan($Paths,$Target,$Credentials) {
    if ($Target -eq 'mcp') { return ,@(New-KiviMcpPlan $Paths $Credentials.key) }
    $creds=Test-KiviCredentials $Credentials.key $Credentials.id
    if ($Target -notin @('both','desktop','cli')) { throw '请选择桌面端、CLI 或两者。' }
    $changes=New-Object 'System.Collections.Generic.List[object]'
    if ($Target -ne 'cli') {
        $metaPath=Join-Path $Paths.desktop '_meta.json'; $raw=Read-KiviFile $metaPath
        if ($null -eq $raw) {
            if ((Test-Path -LiteralPath $Paths.desktop) -and @(Get-ChildItem -LiteralPath $Paths.desktop -Filter '*.json').Count) { throw '桌面配置目录已有文件，但缺少 _meta.json，请先检查原配置。' }
            $meta=[ordered]@{appliedId='';entries=@()}
        } else { $meta=Read-KiviJson $raw '桌面配置索引' }
        if ($meta.hybridPointer) { throw '桌面端正在使用企业托管登录，请先通过原配置方式退出该部署。' }
        if ($meta.entries -isnot [array] -or $meta.appliedId -isnot [string]) { throw '桌面配置索引格式未知，请联系服务方。' }
        $seen=@{}; $candidates=@()
        foreach ($entry in $meta.entries) {
            if ($entry.id -notmatch $script:IdPattern -or $seen.ContainsKey($entry.id) -or $entry.name -isnot [string]) { throw '桌面配置索引含无效或重复记录。' }
            $seen[$entry.id]=$true
            $profileRaw=Read-KiviFile (Join-Path $Paths.desktop ($entry.id+'.json'))
            if ($null -eq $profileRaw) { throw '桌面索引引用了缺失的配置文件，请先修复。' }
            $desktopCfg=Read-KiviJson $profileRaw '桌面已存配置'
            if ($desktopCfg.inferenceGatewayBaseUrl -eq $script:GatewayUrl -and !$desktopCfg.bootstrapUrl -and ($entry.id -eq $meta.appliedId -or $entry.name -eq 'Kividas')) { $candidates += @{entry=$entry;config=$desktopCfg} }
        }
        if ($meta.appliedId -and !$seen.ContainsKey($meta.appliedId)) { throw '桌面当前配置不在索引中，请先修复。' }
        $active=@($candidates | Where-Object { $_.entry.id -eq $meta.appliedId }) | Select-Object -First 1
        if (!$active -and $candidates.Count -gt 1) { throw '找到多份 Kividas 配置，无法确定应更新哪一份。' }
        if (!$active -and $candidates.Count) { $active=$candidates[0] }
        if ($active) { $entry=$active.entry; $desktopCfg=$active.config } else { $entry=[ordered]@{id=[guid]::NewGuid().ToString();name='Kividas'}; $desktopCfg=[ordered]@{} }
        $profilePath=Join-Path $Paths.desktop ($entry.id+'.json')
        if (!$active -and (Test-Path -LiteralPath $profilePath)) { throw '新配置 ID 发生冲突，请重试。' }
        $headers=$desktopCfg.inferenceCustomHeaders
        if ($null -eq $headers) { $headers=[ordered]@{} }
        if ($headers -is [string]) { $headers=Read-KiviJson $headers '桌面自定义请求头' }
        if ($headers -isnot [System.Collections.IDictionary]) { throw '桌面自定义请求头格式不正确。' }
        foreach ($name in @($headers.Keys)) { if ($name -match '^(X-Kividas-Device-ID|Authorization|X-Api-Key)$') { $headers.Remove($name) } }
        $headers['X-Kividas-Device-ID']=$creds.id
        $desktopCfg.inferenceProvider='gateway'; $desktopCfg.inferenceCredentialKind='static'
        $desktopCfg.inferenceGatewayBaseUrl=$script:GatewayUrl; $desktopCfg.inferenceGatewayApiKey=$creds.key
        $desktopCfg.inferenceGatewayAuthScheme='bearer'; $desktopCfg.inferenceCustomHeaders=$headers
        $desktopCfg.modelDiscoveryEnabled=$true; $desktopCfg.isClaudeCodeForDesktopEnabled=$true
        $desktopCfg.Remove('inferenceModels')
        if (!$desktopCfg.deploymentDisplayName) { $desktopCfg.deploymentDisplayName='Kividas' }
        if (!$active) { $meta.entries += ,$entry }
        $meta.appliedId=$entry.id
        $changes.Add(@{path=$profilePath;before=(Read-KiviFile $profilePath);after=(ConvertTo-KiviJson $desktopCfg)})
        $changes.Add(@{path=$metaPath;before=$raw;after=(ConvertTo-KiviJson $meta)})
    }
    if ($Target -ne 'desktop') {
        $raw=Read-KiviFile $Paths.cli; $cli=Read-KiviJson $raw 'CLI settings.json'
        $settingsEnv=$cli.env; if ($null -eq $settingsEnv) { $settingsEnv=[ordered]@{} }
        if ($settingsEnv -isnot [System.Collections.IDictionary]) { throw 'CLI env 格式不正确。' }
        $old=$settingsEnv.ANTHROPIC_CUSTOM_HEADERS; if ($null -eq $old) { $old='' }
        if ($old -isnot [string]) { throw 'CLI 自定义请求头格式不正确。' }
        $rows=@($old -split '\r?\n' | Where-Object { $_.Trim() -and $_ -notmatch '^\s*(x-kividas-device-id|authorization|x-api-key)\s*:' })
        $rows += 'X-Kividas-Device-ID: '+$creds.id
        $settingsEnv.ANTHROPIC_BASE_URL=$script:GatewayUrl; $settingsEnv.ANTHROPIC_AUTH_TOKEN=$creds.key
        $settingsEnv.ANTHROPIC_CUSTOM_HEADERS=$rows -join "`n"; $settingsEnv.CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY='1'
        foreach ($name in @('ANTHROPIC_API_KEY','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_USE_BEDROCK','CLAUDE_CODE_USE_VERTEX','CLAUDE_CODE_USE_FOUNDRY')) { $settingsEnv.Remove($name) }
        foreach ($name in @('apiKeyHelper','forceLoginMethod','forceLoginGatewayUrl','forceLoginOrgUUID')) { $cli.Remove($name) }
        $cli.env=$settingsEnv
        $changes.Add(@{path=$Paths.cli;before=$raw;after=(ConvertTo-KiviJson $cli)})
    }
    if ($Paths.mcp) { foreach ($mcpChange in @(New-KiviMcpPlan $Paths $creds.key)) { $changes.Add($mcpChange) } }
    return ,@($changes | Where-Object { $_.before -cne $_.after })
}
function Save-KiviPlan($Changes,$Backup) {
    if (!$Changes.Count) { return $false }
    foreach ($change in $Changes) { if ((Read-KiviFile $change.path) -cne $change.before) { throw '配置被其他程序更改，请退出客户端后重试。' } }
    $manifest=[ordered]@{version=1;status='pending';restored=$false;entries=@($Changes)}
    Write-KiviFile $Backup (ConvertTo-KiviJson $manifest)
    $written=New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($change in $Changes) {
            if ((Read-KiviFile $change.path) -cne $change.before) { throw 'Concurrent write' }
            $written.Add($change); Write-KiviFile $change.path $change.after
            if ((Read-KiviFile $change.path) -cne $change.after) { throw 'Verify failed' }
        }
        $manifest.status='applied'; Write-KiviFile $Backup (ConvertTo-KiviJson $manifest)
    } catch {
        $errors=0
        for ($i=$written.Count-1;$i -ge 0;$i--) {
            $change=$written[$i]
            try { if ($null -eq $change.before) { Remove-KiviFile $change.path } else { Write-KiviFile $change.path $change.before } } catch { $errors++ }
        }
        $manifest.status='rolled_back';if($errors){$manifest.status='partial'}
        try { Write-KiviFile $Backup (ConvertTo-KiviJson $manifest) } catch {}
        if ($errors) { throw '写入失败，部分恢复未完成。请保留备份并联系服务方。' }
        throw '写入失败，本次更改已恢复。请检查文件权限后重试。'
    }
    return $true
}
function Restore-KiviBackup($Backup,$Paths) {
    $manifest=Read-KiviJson (Read-KiviFile $Backup) '备份'
    if ($manifest.version -ne 1 -or $manifest.status -ne 'applied' -or $manifest.restored -or $manifest.entries -isnot [array]) { throw '该备份不可恢复或已经恢复过。' }
    foreach ($entry in $manifest.entries) {
        $parent=[IO.Path]::GetDirectoryName($entry.path); $name=[IO.Path]::GetFileName($entry.path)
        if ($entry.path -ne $Paths.cli -and $entry.path -ne $Paths.mcp -and !($parent -eq $Paths.desktop -and ($name -eq '_meta.json' -or ($name -match '\.json$' -and [IO.Path]::GetFileNameWithoutExtension($name) -match $script:IdPattern)))) { throw '备份包含意外路径，已停止。' }
        if ($entry.after -isnot [string] -or !($null -eq $entry.before -or $entry.before -is [string])) { throw '备份内容格式不正确。' }
        if ((Read-KiviFile $entry.path) -cne $entry.after) { throw '配置在运行工具后又被修改。为保留后续更改，本次不自动恢复，请联系服务方使用备份。' }
    }
    $done=New-Object 'System.Collections.Generic.List[object]'
    try {
        for($i=$manifest.entries.Count-1;$i -ge 0;$i--) {
            $entry=$manifest.entries[$i]; $done.Add($entry)
            if($null -eq $entry.before) { Remove-KiviFile $entry.path } else { Write-KiviFile $entry.path $entry.before }
        }
    } catch {
        for($i=$done.Count-1;$i -ge 0;$i--) { try { Write-KiviFile $done[$i].path $done[$i].after } catch {} }
        throw '恢复未完成，请保留备份并检查文件权限。'
    }
    $manifest.restored=$true; Write-KiviFile $Backup (ConvertTo-KiviJson $manifest)
}
function Test-KiviMcpKey($Key) {
    $Key=([string]$Key).Trim()
    if ($Key -cnotmatch '^sk-kiv-desktop-[A-Za-z0-9_-]{40,128}$') { throw '未找到完整的 Kividas 网关 Key。' }
    return $Key
}
function New-KiviMcpPlan($Paths,$Key) {
    $Key=Test-KiviMcpKey $Key
    if (!$Paths.mcp) { throw '缺少 MCP 配置位置。' }
    $raw=Read-KiviFile $Paths.mcp;$config=Read-KiviJson $raw 'MCP .claude.json'
    $servers=$config.mcpServers;if ($null -eq $servers) { $servers=[ordered]@{} }
    if ($servers -isnot [System.Collections.IDictionary]) { throw 'MCP 列表格式不正确，未修改配置。' }
    $servers['kividas-usage']=[ordered]@{type='http';url=($script:GatewayUrl+'/mcp/usage');headers=[ordered]@{Authorization=('Bearer '+$Key)}}
    $legacy=$servers['kividas-usage-remote']
    if ($legacy -and $legacy.type -eq 'http' -and $legacy.url -ceq ($script:GatewayUrl+'/mcp/usage')) { $servers.Remove('kividas-usage-remote') }
    $config.mcpServers=$servers;$after=ConvertTo-KiviJson $config
    if ($raw -cne $after) { return @{path=$Paths.mcp;before=$raw;after=$after} }
}
function Open-KiviDesktopKey($Value) {
    if (!$Value -or !$Value.StartsWith('__sealed__:v1:')) { return $Value }
    Add-Type -AssemblyName System.Security
    $protection='anthropic.claude.crossProfileSecret.v1'
    $plain=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($Value.Substring('__sealed__:v1:'.Length)),[Text.Encoding]::UTF8.GetBytes($protection),[Security.Cryptography.DataProtectionScope]::CurrentUser)
    try {
        $text=[Text.Encoding]::UTF8.GetString($plain)
        if (!$text.StartsWith($protection+':')) { throw 'Invalid sealed key' }
        $record=Read-KiviJson $text.Substring($protection.Length+1) '桌面加密配置'
        if ($record.configLibrary.key -ne 'inferenceGatewayApiKey') { throw 'Invalid sealed field' }
        return $record.configLibrary.value
    } finally { [Array]::Clear($plain,0,$plain.Length) }
}
function Get-KiviExistingKeys($Paths) {
    $found=New-Object 'System.Collections.Generic.List[object]'
    $raw=Read-KiviFile $Paths.cli
    if ($null -ne $raw) {
        $cli=Read-KiviJson $raw 'CLI settings.json'
        if ($cli.env.ANTHROPIC_BASE_URL -in @($script:GatewayUrl,($script:GatewayUrl+'/'))) {
            $candidate=$cli.env.ANTHROPIC_AUTH_TOKEN;if (!$candidate) { $candidate=$cli.env.ANTHROPIC_API_KEY }
            try { $found.Add(@{key=(Test-KiviMcpKey $candidate);source='Claude Code CLI'}) } catch {}
        }
    }
    $raw=Read-KiviFile (Join-Path $Paths.desktop '_meta.json')
    if ($null -ne $raw) {
        $meta=Read-KiviJson $raw '桌面配置索引'
        if ($meta.appliedId -match $script:IdPattern -and !$meta.hybridPointer) {
            $raw=Read-KiviFile (Join-Path $Paths.desktop ($meta.appliedId+'.json'))
            if ($null -ne $raw) {
                $config=Read-KiviJson $raw '桌面配置'
                if ($config.inferenceProvider -eq 'gateway' -and $config.inferenceGatewayBaseUrl -in @($script:GatewayUrl,($script:GatewayUrl+'/'))) {
                    try { $candidate=Test-KiviMcpKey (Open-KiviDesktopKey $config.inferenceGatewayApiKey);if (!@($found | Where-Object {$_.key -ceq $candidate}).Count) { $found.Add(@{key=$candidate;source='Claude Desktop'}) } } catch {}
                }
            }
        }
    }
    return $found.ToArray()
}
function Test-KiviRemoteMcp($Key) {
    $Key=Test-KiviMcpKey $Key
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    $body='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"kividas-setup","version":"r4"}}}'
    try {
        $reply=Invoke-RestMethod -Uri ($script:GatewayUrl+'/mcp/usage') -Method Post -Headers @{Authorization=('Bearer '+$Key);Accept='application/json, text/event-stream'} -ContentType 'application/json' -Body $body -TimeoutSec 15 -MaximumRedirection 0
        if ($reply.result.serverInfo.name -ne 'kividas-usage') { throw 'Unexpected MCP server' }
        return $true
    } catch {
        if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -in @(401,403)) { return $false }
        throw '暂时无法验证用量服务，请联网后重试。本次未修改配置。'
    }
}

function Start-KiviSetup {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form=New-Object Windows.Forms.Form
    $form.Text='Kividas 一键配置 · 2026-11-04 r4'; $form.ClientSize=New-Object Drawing.Size(620,370)
    $form.StartPosition='CenterScreen'; $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false
    $form.Font=New-Object Drawing.Font('Microsoft YaHei UI',9)
    function Label($Text,$Top) { $label=New-Object Windows.Forms.Label; $label.Text=$Text; $label.Location=New-Object Drawing.Point(22,$Top); $label.Size=New-Object Drawing.Size(575,30); $form.Controls.Add($label) }
    Label '先结束任务并完全退出 Claude。无需管理员权限。' 18
    $target=New-Object Windows.Forms.ComboBox; $target.DropDownStyle='DropDownList'
    $target.Location=New-Object Drawing.Point(22,55);$target.Size=New-Object Drawing.Size(360,30)
    [void]$target.Items.AddRange(@('老用户：只补用量 MCP','配置桌面端和 CLI（含 MCP）','只配置桌面端（含 MCP）','只配置 CLI（含 MCP）','恢复上一次配置'));$target.SelectedIndex=0;$form.Controls.Add($target)
    $import=New-Object Windows.Forms.Button;$import.Text='读取客户 TXT';$import.Location=New-Object Drawing.Point(405,53);$import.Size=New-Object Drawing.Size(190,32);$form.Controls.Add($import)
    Label 'Gateway API key' 102
    $key=New-Object Windows.Forms.TextBox;$key.UseSystemPasswordChar=$true;$key.Location=New-Object Drawing.Point(22,129);$key.Size=New-Object Drawing.Size(575,30);$form.Controls.Add($key)
    Label '安装识别码（仅新配置网关时需要）' 174
    $device=New-Object Windows.Forms.TextBox;$device.Location=New-Object Drawing.Point(22,201);$device.Size=New-Object Drawing.Size(575,30);$form.Controls.Add($device)
    Label '老用户可直接开始，自动读取身份；新用户先读取接入 TXT。' 249
    $apply=New-Object Windows.Forms.Button;$apply.Text='开始配置';$apply.Location=New-Object Drawing.Point(405,304);$apply.Size=New-Object Drawing.Size(190,38);$form.Controls.Add($apply);$form.AcceptButton=$apply
    $import.Add_Click({
        try { $pick=New-Object Windows.Forms.OpenFileDialog;$pick.Filter='客户接入资料 (*.txt)|*.txt';if($pick.ShowDialog() -eq 'OK'){$creds=Read-KiviCredentialsText (Read-KiviFile $pick.FileName);$key.Text=$creds.key;$device.Text=$creds.id} }
        catch { [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'无法读取资料') }
    })
    $device.Enabled=$false
    $target.Add_SelectedIndexChanged({ $device.Enabled=$target.SelectedIndex -in @(1,2,3);$key.Enabled=$target.SelectedIndex -ne 4;$import.Enabled=$target.SelectedIndex -ne 4 })
    $apply.Add_Click({
        try {
            $selected=@('mcp','both','desktop','cli','both')[$target.SelectedIndex]
            if ($env:CLAUDE_CONFIG_DIR -or $env:CLAUDE_USER_DATA_DIR) { throw '检测到自定义配置目录，请联系服务方适配该位置。' }
            if ($selected -notin @('cli','mcp') -and @(Get-Process -Name Claude -ErrorAction SilentlyContinue).Count) { throw '请先结束任务，并从 Claude 菜单选择 File → Exit，再运行配置。' }
            if ($selected -ne 'cli') { foreach($hive in @('HKLM:\SOFTWARE\Policies\Claude','HKCU:\SOFTWARE\Policies\Claude')) { if((Test-Path $hive) -and (Get-Item $hive).GetValueNames().Count){throw '此电脑有 Claude 管理配置，请联系管理员；工具不会覆盖它。'} } }
            if ($selected -ne 'desktop') {
                if (Test-Path (Join-Path $env:ProgramFiles 'ClaudeCode\managed-settings.json')) { throw 'CLI 已有管理策略，请联系管理员确认接入方式。' }
                foreach($hive in @('HKLM:\SOFTWARE\Policies\ClaudeCode','HKCU:\SOFTWARE\Policies\ClaudeCode')) { if(Test-Path $hive){throw 'CLI 已有管理策略，请联系管理员确认接入方式。'} }
            }
            $paths=@{desktop=(Join-Path $env:LOCALAPPDATA 'Claude-3p\configLibrary');cli=(Join-Path $env:USERPROFILE '.claude\settings.json');mcp=(Join-Path $env:USERPROFILE '.claude.json')}
            if ($selected -ne 'cli' -and !(Test-Path (Join-Path $env:LOCALAPPDATA 'Claude-3p')) -and (Test-Path (Join-Path $env:APPDATA 'Claude-3p'))) { throw '检测到旧版桌面数据目录。请先启动更新后的官方 Claude 完成原数据迁移，退出后再配置。' }
            $backups=Join-Path $env:LOCALAPPDATA 'KividasSetup\backups'
            if ($target.SelectedIndex -eq 4) {
                $pending=@(Get-ChildItem -LiteralPath $backups -Filter '*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Where-Object { $m=Read-KiviJson (Read-KiviFile $_.FullName) '备份'; $m.status -eq 'applied' -and !$m.restored })
                if (!$pending.Count) { throw '没有可以恢复的备份。' }
                Restore-KiviBackup $pending[0].FullName $paths
                [void][Windows.Forms.MessageBox]::Show('已恢复上一次配置，请重新打开对应客户端。','完成');$form.Close();return
            }
            if ($selected -eq 'mcp') {
                $creds=$null
                if ($key.Text.Trim()) {
                    $candidate=Test-KiviMcpKey $key.Text
                    if (!(Test-KiviRemoteMcp $candidate)) { throw 'Key 无效或订阅暂不可用。原配置未修改。' }
                    $creds=@{key=$candidate}
                } else {
                    foreach ($candidate in @(Get-KiviExistingKeys $paths)) {
                        if (Test-KiviRemoteMcp $candidate.key) { $creds=@{key=$candidate.key};break }
                    }
                    if (!$creds) { throw '未找到有效网关身份。请读取原接入 TXT 或填写 Key，再点击开始配置；只补 MCP 不需要识别码。' }
                }
            } else {
                $creds=Test-KiviCredentials $key.Text $device.Text
                if (!(Test-KiviRemoteMcp $creds.key)) { throw 'Key 无效或订阅暂不可用。原配置未修改。' }
            }
            $changes=New-KiviPlan $paths $selected $creds
            $backup=Join-Path $backups ((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH-mm-ss-fff')+'-'+[guid]::NewGuid().ToString()+'.json')
            $changed=Save-KiviPlan $changes $backup
            if ($selected -eq 'mcp') { [void][Windows.Forms.MessageBox]::Show('用量 MCP 已接入并验证。请重新打开 Claude Code 会话，再说「查询我的 Kividas 用量」。原网关配置保持不变。','完成');$form.Close();return }
            $message='网关与用量 MCP 已配置，原配置已自动备份。';if(!$changed){$message='配置已经一致，无需重复写入。'}
            $message+="`n`n请重新打开 Claude 或重新启动 CLI。桌面首次可能需点击 Continue；若仍在个人账号模式，退出登录后选择网关。`n`nCLI 运行 /status 检查地址，再发送一条消息。文件写入成功不等于联网验证成功。`n`n如需撤销，再运行工具选择「恢复上一次配置」。"
            [void][Windows.Forms.MessageBox]::Show($message,'完成');$form.Close()
        } catch { [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'未完成配置') }
    })
    [void]$form.ShowDialog()
}
if (!$LibraryOnly) { Start-KiviSetup }
