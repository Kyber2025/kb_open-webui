/* Pure configuration logic; no network or account access. Also tested under Node. */
var Kivi = (function () {
    'use strict';
    var URL = 'https://ai.kividas.com/api';
    var ID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
    function fail(s) { throw new Error(s); }
    function object(v, label) {
        if (!v || typeof v !== 'object' || Array.isArray(v)) fail(label + ' 格式不正确，未修改配置。');
        return v;
    }
    function parse(raw, label) {
        if (raw === null) return {};
        try { return object(JSON.parse(raw.replace(/^\uFEFF/, '')), label); }
        catch (_) { fail(label + ' 不是有效 JSON，请先修复；原文件未覆盖。'); }
    }
    function validate(key, id) {
        key = String(key || '').trim(); id = String(id || '').trim();
        if (!/^sk-kiv-desktop-[A-Za-z0-9_-]{40,128}$/.test(key)) fail('请填写完整的 Kividas Gateway API key。');
        if (!ID.test(id)) fail('安装识别码应为管理员配发的 UUID；不要自行生成或更换。');
        return { key: key, id: id };
    }
    function fromText(text) {
        var keys = [], ids = [];
        String(text).replace(/^\uFEFF/, '').split(/\r?\n/).forEach(function (line) {
            var k = /^\s*Gateway API key\s*[:：]\s*(\S+)\s*$/i.exec(line);
            var d = /^\s*(?:安装识别码|Installation ID|值[（(]Value[）)])\s*[:：]\s*(\S+)\s*$/i.exec(line);
            if (k) keys.push(k[1]); if (d) ids.push(d[1]);
        });
        if (keys.length !== 1 || ids.length !== 1) fail('TXT 必须包含一套明确的 Gateway API key 和安装识别码（或“值（Value）”）。请使用后台下载的客户接入资料。');
        return validate(keys[0], ids[0]);
    }
    function json(v) { return JSON.stringify(v, null, 2) + '\n'; }
    function keyOnly(key) {
        key=String(key||'').trim();
        if(!/^sk-kiv-desktop-[A-Za-z0-9_-]{40,128}$/.test(key)) fail('未找到完整的 Kividas 网关 Key。请读取原接入资料 TXT，或手动填写 Key。');
        return key;
    }
    function mcpPlan(fs,paths,key) {
        if(!paths.mcp) fail('缺少 MCP 配置位置。');
        var before=fs.read(paths.mcp), cfg=parse(before,'MCP .claude.json');
        var servers=cfg.mcpServers===undefined?{}:object(cfg.mcpServers,'MCP 列表');
        servers['kividas-usage']={type:'http',url:URL+'/mcp/usage',headers:{Authorization:'Bearer '+keyOnly(key)}};
        var legacy=servers['kividas-usage-remote'];
        if(legacy && legacy.type==='http' && legacy.url===URL+'/mcp/usage')delete servers['kividas-usage-remote'];
        cfg.mcpServers=servers;
        var after=json(cfg);return before===after?[]:[{path:paths.mcp,before:before,after:after}];
    }
    function existingKeys(fs,paths,openKey) {
        var out=[];
        function add(key,source){try{key=keyOnly(key);if(!out.some(function(x){return x.key===key;}))out.push({key:key,source:source});}catch(_){} }
        var raw=fs.read(paths.cli);
        if(raw!==null){var cli=parse(raw,'CLI settings.json'),env=cli.env||{};if(env.ANTHROPIC_BASE_URL===URL||env.ANTHROPIC_BASE_URL===URL+'/')add(env.ANTHROPIC_AUTH_TOKEN||env.ANTHROPIC_API_KEY,'Claude Code CLI');}
        var metaRaw=fs.read(paths.desktop+'/_meta.json');
        if(metaRaw!==null){
            var meta=parse(metaRaw,'桌面配置索引');
            if(ID.test(meta.appliedId)&&!meta.hybridPointer){
                var profileRaw=fs.read(paths.desktop+'/'+meta.appliedId+'.json');
                if(profileRaw!==null){var cfg=parse(profileRaw,'桌面配置');
                    if(cfg.inferenceProvider==='gateway'&&(cfg.inferenceGatewayBaseUrl===URL||cfg.inferenceGatewayBaseUrl===URL+'/')){
                        var key=cfg.inferenceGatewayApiKey;
                        if(typeof key==='string'&&key.indexOf('__sealed__:v1:')===0)key=openKey?openKey(key):null;
                        add(key,'Claude Desktop');
                    }
                }
            }
        }
        return out;
    }
    function repairLegacyAlias(raw, officialCli) {
        if (raw === null) return null;
        function quote(s) { return "'"+s.replace(/'/g,"'\\''")+"'"; }
        return raw.split('\n').map(function(line) {
            var m=/^[ \t]*alias[ \t]+claude[ \t]*=[ \t]*(['"])([^\r\n]*)\1[ \t]*(?:#.*)?\r?$/.exec(line);
            if (!m) return line;
            var value=m[2].trim();
            if ((value[0]==='"'||value[0]==="'") && value[value.length-1]===value[0]) value=value.slice(1,-1);
            if(value!=='/Applications/Kividas Code.app/Contents/Resources/cli/claude')return line;
            if(!officialCli)fail('检测到旧 Kividas 的 claude 命令入口，但未找到可用的官方 Claude Code CLI。请先安装官方 CLI，再重新运行配置；安装过旧 Kividas 桌面端不代表已安装官方 CLI。本次未修改配置。');
            // Quote twice: once for shell assignment, once for alias expansion.
            // An absolute executable avoids a stale Kividas PATH entry winning.
            return 'alias claude='+quote(quote(officialCli))+' # Kividas setup: official Claude Code CLI'+(/\r$/.test(line)?'\r':'');
        }).join('\n');
    }
    function plan(fs, paths, target, credentials) {
        if(target==='mcp')return mcpPlan(fs,paths,credentials.key);
        var creds = validate(credentials.key, credentials.id), changes = [];
        function add(path, data) { changes.push({path:path, before:fs.read(path), after:json(data)}); }
        if (['both','desktop','cli'].indexOf(target) < 0) fail('请选择桌面端、CLI 或两者。');
        if (target !== 'cli') {
            var metaPath = paths.desktop + '/_meta.json', raw = fs.read(metaPath);
            if (raw === null && fs.list(paths.desktop).some(function(n){ return /\.json$/i.test(n); }))
                fail('桌面配置目录已有文件，但缺少 _meta.json。请先检查原配置，避免建立重复配置。');
            var meta = raw === null ? {appliedId:'',entries:[]} : parse(raw, '桌面配置索引');
            if (meta.hybridPointer) fail('桌面端正在使用企业托管登录，请先通过原配置方式退出该部署。');
            if (!Array.isArray(meta.entries) || typeof meta.appliedId !== 'string') fail('桌面配置索引格式未知，请更新工具或联系服务方。');
            var seen = {}, candidates = [];
            meta.entries.forEach(function(e) {
                if (!e || !ID.test(e.id) || seen[e.id] || typeof e.name !== 'string') fail('桌面配置索引含无效或重复记录。');
                seen[e.id] = true;
                var content = fs.read(paths.desktop + '/' + e.id + '.json');
                if (content === null) fail('桌面配置索引引用了缺失的配置文件，请先修复。');
                var cfg = parse(content, '桌面已存配置');
                if (cfg.inferenceGatewayBaseUrl === URL && !cfg.bootstrapUrl && (e.id === meta.appliedId || e.name === 'Kividas'))
                    candidates.push({entry:e,config:cfg});
            });
            if (meta.appliedId && !seen[meta.appliedId]) fail('桌面当前配置不在索引中，请先修复。');
            var active = candidates.filter(function(x){return x.entry.id===meta.appliedId;})[0];
            if (!active && candidates.length > 1) fail('找到多份 Kividas 配置，无法确定应更新哪一份。');
            active = active || candidates[0];
            var entry = active ? active.entry : {id:fs.uuid(),name:'Kividas'};
            var profile = active ? active.config : {};
            if (!ID.test(entry.id)) fail('无法创建桌面配置 ID。');
            if (!active && fs.read(paths.desktop+'/'+entry.id+'.json') !== null) fail('新配置 ID 发生冲突，请重试。');
            var headers = profile.inferenceCustomHeaders || {};
            if (typeof headers === 'string') headers = parse(headers, '桌面自定义请求头');
            object(headers, '桌面自定义请求头');
            Object.keys(headers).forEach(function(k){if(/^(x-kividas-device-id|authorization|x-api-key)$/i.test(k)) delete headers[k];});
            headers['X-Kividas-Device-ID'] = creds.id;
            profile.inferenceProvider='gateway'; profile.inferenceCredentialKind='static';
            profile.inferenceGatewayBaseUrl=URL; profile.inferenceGatewayApiKey=creds.key;
            profile.inferenceGatewayAuthScheme='bearer'; profile.inferenceCustomHeaders=headers;
            profile.modelDiscoveryEnabled=true; profile.isClaudeCodeForDesktopEnabled=true;
            delete profile.inferenceModels;
            if (!profile.deploymentDisplayName) profile.deploymentDisplayName='Kividas';
            if (!active) meta.entries.push(entry);
            meta.appliedId=entry.id;
            add(paths.desktop+'/'+entry.id+'.json',profile);
            add(metaPath,meta);
        }
        if (target !== 'desktop') {
            var cli = parse(fs.read(paths.cli),'CLI settings.json');
            var env = cli.env === undefined ? {} : object(cli.env,'CLI env');
            var old = env.ANTHROPIC_CUSTOM_HEADERS || '';
            if (typeof old !== 'string') fail('CLI 自定义请求头格式不正确。');
            var rows=old.split(/\r?\n/).filter(function(s){return s.trim() && !/^\s*(x-kividas-device-id|authorization|x-api-key)\s*:/i.test(s);});
            rows.push('X-Kividas-Device-ID: '+creds.id);
            env.ANTHROPIC_BASE_URL=URL; env.ANTHROPIC_AUTH_TOKEN=creds.key;
            env.ANTHROPIC_CUSTOM_HEADERS=rows.join('\n'); env.CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY='1';
            ['ANTHROPIC_API_KEY','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_USE_BEDROCK','CLAUDE_CODE_USE_VERTEX','CLAUDE_CODE_USE_FOUNDRY'].forEach(function(k){delete env[k];});
            ['apiKeyHelper','forceLoginMethod','forceLoginGatewayUrl','forceLoginOrgUUID'].forEach(function(k){delete cli[k];});
            cli.env=env; add(paths.cli,cli);
            (paths.shellFiles||[]).forEach(function(path) {
                var before=fs.read(path), after=repairLegacyAlias(before,paths.officialCli);
                if(before!==after)changes.push({path:path,before:before,after:after});
            });
        }
        if(paths.mcp)changes=changes.concat(mcpPlan(fs,paths,creds.key));
        return changes.filter(function(x){return x.before!==x.after;});
    }
    function commit(fs, changes, backup) {
        if (!changes.length) return false;
        changes.forEach(function(x){if(fs.read(x.path)!==x.before) fail('配置在操作期间被其他程序更改，请退出客户端后重试。');});
        var manifest={version:1,status:'pending',restored:false,entries:changes};
        fs.write(backup,json(manifest));
        var written=[];
        try {
            changes.forEach(function(x){
                if(fs.read(x.path)!==x.before) fail('检测到配置被同时修改。');
                written.push(x); fs.write(x.path,x.after);
                if(fs.read(x.path)!==x.after) fail('配置写入校验失败。');
            });
            manifest.status='applied';fs.write(backup,json(manifest));
        } catch(e) {
            var errors=0;
            written.reverse().forEach(function(x){try{if(x.before===null)fs.remove(x.path);else fs.write(x.path,x.before);}catch(_){errors++;}});
            manifest.status=errors?'partial':'rolled_back';try{fs.write(backup,json(manifest));}catch(_){}
            fail(errors ? '写入失败，部分恢复未完成。请保留备份并联系服务方。' : '写入失败，本次更改已恢复。请检查文件权限后重试。');
        }
        return true;
    }
    function restore(fs, backup, paths) {
        var m=parse(fs.read(backup),'备份');
        if(m.version!==1 || m.status!=='applied' || m.restored || !Array.isArray(m.entries)) fail('该备份不可恢复或已经恢复过。');
        m.entries.forEach(function(x){
            var name=x.path.slice(paths.desktop.length+1);
            if(x.path!==paths.cli && x.path!==paths.mcp && (paths.shellFiles||[]).indexOf(x.path)<0 && !(x.path.indexOf(paths.desktop+'/')===0 && (name==='_meta.json'||ID.test(name.replace(/\.json$/,''))&&/\.json$/.test(name)))) fail('备份包含意外路径，已停止。');
            if(typeof x.after!=='string'||!(x.before===null||typeof x.before==='string')) fail('备份内容格式不正确。');
            if(fs.read(x.path)!==x.after) fail('配置在运行工具后又被修改。为保留后续更改，本次不自动恢复，请联系服务方使用备份。');
        });
        var done=[];
        try {
            m.entries.slice().reverse().forEach(function(x){done.push(x);if(x.before===null)fs.remove(x.path);else fs.write(x.path,x.before);});
        } catch(e) {
            done.reverse().forEach(function(x){try{fs.write(x.path,x.after);}catch(_){}});
            fail('恢复未完成，请保留备份并检查文件权限。');
        }
        m.restored=true;fs.write(backup,json(m));return true;
    }
    return {validate:validate,keyOnly:keyOnly,existingKeys:existingKeys,fromText:fromText,parse:parse,plan:plan,commit:commit,restore:restore};
}());
if (typeof module !== 'undefined') module.exports=Kivi;
