ObjC.import('Foundation');
ObjC.import('AppKit');
var fm=$.NSFileManager.defaultManager;
function exists(p){return fm.fileExistsAtPath($(p));}
function safePath(p){
    var current=p;
    while(current && current!=='/'){
        if(exists(current)){
            var a=fm.attributesOfItemAtPathError($(current),null);
            if(ObjC.unwrap(a.objectForKey($.NSFileType))===ObjC.unwrap($.NSFileTypeSymbolicLink)) throw Error('配置路径含符号链接，请联系服务方确认位置。');
        }
        current=current.substring(0,current.lastIndexOf('/'));
    }
}
function read(p){
    safePath(p);if(!exists(p))return null;
    var s=$.NSString.stringWithContentsOfFileEncodingError($(p),$.NSUTF8StringEncoding,null);
    if(!s)throw Error('无法读取配置文件，请检查权限和 UTF-8 编码。');
    return ObjC.unwrap(s);
}
function mkdir(p){
    safePath(p);
    if(!exists(p)&&!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(p),true,$({NSFilePosixPermissions:448}),null)) throw Error('无法创建配置目录。');
}
function write(p,s){
    safePath(p);mkdir(p.substring(0,p.lastIndexOf('/')));
    if(!$(s).writeToFileAtomicallyEncodingError($(p),true,$.NSUTF8StringEncoding,null))throw Error('无法写入配置文件。');
    if(!fm.setAttributesOfItemAtPathError($({NSFilePosixPermissions:384}),$(p),null))throw Error('无法设置配置文件权限。');
}
function list(p){safePath(p);return exists(p)?ObjC.unwrap(fm.contentsOfDirectoryAtPathError($(p),null)):[];}
function remove(p){safePath(p);if(exists(p)&&!fm.removeItemAtPathError($(p),null))throw Error('无法恢复文件。');}
var fs={read:read,write:write,list:list,remove:remove,uuid:function(){return ObjC.unwrap($.NSUUID.UUID.UUIDString).toLowerCase();}};
function shellFiles(home){return ['.zshrc','.zprofile','.zshenv','.zlogin','.bashrc','.bash_profile','.profile'].map(function(n){return home+'/'+n;});}
function officialCli(home){
    return [home+'/.local/bin/claude','/opt/homebrew/bin/claude','/usr/local/bin/claude'].filter(function(p){
        var resolved=ObjC.unwrap($(p).stringByResolvingSymlinksInPath);
        return fm.isExecutableFileAtPath($(p)) && !/\/Kividas Code\.app\/|\/\.kividas\//.test(resolved);
    })[0];
}
function run(args){
    var packageDir=args[0];
    eval(read(packageDir+'/core.js'));
    // Test entry point only uses an explicit temporary tree, never the account's config.
    if(args[1]==='--fixture'){
        var request=JSON.parse(read(args[2]));
        var root=request.root;
        if(!/^\/private\/tmp\/kividas-fixture-[a-zA-Z0-9_-]+$/.test(root))throw Error('Invalid fixture root');
        var testPaths={desktop:root+'/desktop',cli:root+'/cli/settings.json',shellFiles:shellFiles(root),officialCli:officialCli(root)};
        if(request.action==='restore'){Kivi.restore(fs,root+'/backup.json',testPaths);return 'restored';}
        var changes=Kivi.plan(fs,testPaths,request.target,request.credentials);
        Kivi.commit(fs,changes,root+'/backup.json');return 'configured '+changes.length;
    }
    var app=Application.currentApplication();app.includeStandardAdditions=true;
    var home=ObjC.unwrap($.NSHomeDirectory());
    var paths={desktop:home+'/Library/Application Support/Claude-3p/configLibrary',cli:home+'/.claude/settings.json'};
    paths.shellFiles=shellFiles(home);
    paths.officialCli=officialCli(home);
    var backups=home+'/Library/Application Support/KividasSetup/backups';
    function dialog(s){return app.displayDialog(s,{withTitle:'Kividas 一键配置 · 2026-10-26 r2',buttons:['好'],defaultButton:'好'});}
    function choose(items,prompt){var result=app.chooseFromList(items,{withTitle:'Kividas 一键配置',withPrompt:prompt,defaultItems:[items[0]],multipleSelectionsAllowed:false});if(result===false)throw Error('cancelled');return result[0];}
    try{
        var action=choose(['配置桌面端和 CLI','只配置桌面端','只配置 CLI','恢复上一次配置'],'先结束任务并退出 Claude。选择需要配置的客户端：');
        var target=action==='只配置桌面端'?'desktop':action==='只配置 CLI'?'cli':'both';
        if(ObjC.unwrap($.NSProcessInfo.processInfo.environment.objectForKey('CLAUDE_CONFIG_DIR')) || ObjC.unwrap($.NSProcessInfo.processInfo.environment.objectForKey('CLAUDE_USER_DATA_DIR')))throw Error('检测到自定义配置目录，请联系服务方适配该位置。');
        if(target!=='cli'&&$.NSRunningApplication.runningApplicationsWithBundleIdentifier('com.anthropic.claudefordesktop').count>0)throw Error('请先等待任务结束，并在 Claude 菜单中选择 Quit Claude，然后重新运行工具。');
        if(target!=='cli'){
            [' /Library/Managed Preferences/com.anthropic.claudefordesktop.plist','/Library/Managed Preferences/'+ObjC.unwrap($.NSUserName())+'/com.anthropic.claudefordesktop.plist'].forEach(function(p){if(exists(p.trim()))throw Error('此电脑有 Claude 管理配置，请联系管理员；工具不会覆盖它。');});
        }
        if(target!=='desktop'&&exists('/Library/Application Support/ClaudeCode/managed-settings.json'))throw Error('CLI 已有管理策略，请联系管理员确认接入方式。');
        if(action==='恢复上一次配置'){
            var names=list(backups).filter(function(n){return /^\d.*\.json$/.test(n);}).sort().reverse();
            var pending=names.filter(function(n){var m=Kivi.parse(read(backups+'/'+n),'备份');return m.status==='applied'&&!m.restored;});
            if(!pending.length)throw Error('没有可以恢复的备份。');
            Kivi.restore(fs,backups+'/'+pending[0],paths);dialog('已恢复上一次配置。请重新打开对应客户端。');return;
        }
        var source=choose(['读取客户接入资料 TXT','手动填写 Key 和识别码'],'可直接使用管理员下载的客户接入资料 TXT。');
        var creds;
        if(source==='读取客户接入资料 TXT'){
            var file=app.chooseFile({withPrompt:'选择客户接入资料 TXT',ofType:['txt']});
            creds=Kivi.fromText(read(String(file)));
        }else{
            var key=app.displayDialog('粘贴完整 Gateway API key：',{withTitle:'Kividas 一键配置',defaultAnswer:'',hiddenAnswer:true}).textReturned;
            var id=app.displayDialog('粘贴与这个 Key 配套的安装识别码：',{withTitle:'Kividas 一键配置',defaultAnswer:''}).textReturned;
            creds=Kivi.validate(key,id);
        }
        var changes=Kivi.plan(fs,paths,target,creds);
        var backup=backups+'/'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+fs.uuid()+'.json';
        var changed=Kivi.commit(fs,changes,backup);
        var repaired=changes.some(function(x){return paths.shellFiles.indexOf(x.path)>=0;});
        dialog((changed?'配置已保存，原配置已自动备份。':'配置已经一致，无需重复写入。')+(repaired?'\n已将旧 Kividas 的 claude 命令入口改为已安装的官方 CLI。请关闭旧终端并打开新窗口。':'')+'\n\n请重新打开 Claude 或重新启动 CLI。桌面首次可能需点击 Continue；若仍在个人账号模式，退出登录后选择网关。\n\nCLI 运行 /status 检查地址，再发送一条消息。文件写入成功不等于联网验证成功。\n\n如需撤销，再次打开本工具选择“恢复上一次配置”。');
    }catch(e){if(String(e).indexOf('cancelled')>=0||e.errorNumber===-128)return;dialog(String(e.message||e));}
}
